package kr.ac.kumoh.ce.s20110766.mytcp;

import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by woong on 2017-05-10.
 */
public class Alarm {


    private Calendar cal; //점수
    private int index;
    private boolean set;
    private List<Integer> day;
    private String smart;


    public Alarm() {
        this.day = new ArrayList<Integer>();
    }//여기서는 set이 필요없다 생성할때 생성자에서 다 설정해주면 되기때문이다.

    public Calendar getCal() {
        return this.cal;
    }

    public void setCal(Calendar cal_) {
        this.cal = cal_;
    }

    public int getIndex() {
        return this.index;
    }

    public void setIndex(int index_) {
        this.index = index_;
    }

    public void set(boolean set_) {
        this.set = set_;
    }

    public boolean getset() {
        return this.set;
    }

    public List<Integer> getday() {
        return this.day;
    }

    public String getsmart() {
        return this.smart;
    }

    public void setsmart(String smart_) { this.smart = smart_;}

    public void setday(Integer day_) {
        this.day.add(day_);
    }

    public void deleteday(int index_) {
        this.day.remove(index_);
    }

    public void clear_list() {
        this.day.clear();
    }

    public void change() {
        Integer temp;
        temp = this.day.get(0);
        this.day.remove(0);
        this.day.add(temp);
        Log.i("change",temp.toString());
    }

}
