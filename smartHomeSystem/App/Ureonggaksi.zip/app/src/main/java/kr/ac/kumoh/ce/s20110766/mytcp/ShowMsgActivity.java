package kr.ac.kumoh.ce.s20110766.mytcp;


import android.app.Activity;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by woong on 2017-04-07.
 */
public class ShowMsgActivity extends Activity {
    private String notiMessage;
    Intent mAlarmIntent;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        mAlarmIntent = new Intent(getApplicationContext(), AlarmSoundService.class);
        super.onCreate(savedInstanceState);


        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
                WindowManager.LayoutParams.FLAG_BLUR_BEHIND);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        setContentView(R.layout.alertdialog);
        Button adButton = (Button) findViewById(R.id.submit);
        adButton.setOnClickListener(new SubmitOnClickListener());

    }

    private class SubmitOnClickListener implements View.OnClickListener {

        public void onClick(View v) {
            stopService(mAlarmIntent);
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(mAlarmIntent);
    }
}



