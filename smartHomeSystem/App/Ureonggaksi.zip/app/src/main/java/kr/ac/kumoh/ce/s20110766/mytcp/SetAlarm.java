package kr.ac.kumoh.ce.s20110766.mytcp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by 태훈 on 2017-04-07.
 */
public class SetAlarm extends AppCompatActivity {

    int temp_index;
    int[] date;
    String smart;
    Button mon;
    Button tue;
    Button wed;
    Button thu;
    Button fri;
    Button sat;
    Button sun;
    Button all;
    Button on;
    Button off;
    EditText hour;
    EditText minute;
    Intent getintent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setalarm);
        hour = (EditText) findViewById(R.id.ehour);
        minute = (EditText) findViewById(R.id.eminute);
        mon = (Button) findViewById(R.id.monday);
        tue = (Button) findViewById(R.id.tuesday);
        wed = (Button) findViewById(R.id.wednesday);
        thu = (Button) findViewById(R.id.thursday);
        fri = (Button) findViewById(R.id.friday);
        sat = (Button) findViewById(R.id.saterday);
        sun = (Button) findViewById(R.id.sunday);
        all = (Button) findViewById(R.id.allday);
        on = (Button) findViewById(R.id.on);
        off = (Button) findViewById(R.id.off);
        getintent = getIntent();
        date = new int[8];

        for (int i = 0; i < 8; i++) {
            date[i] = 0;
        }
        smart = "on";
    }

    public void onMonday(View v) {
        if (date[2] == 0 && date[0] == 0) {
            mon.setBackgroundColor(Color.rgb(100, 100, 100));
            date[2] = 1;

            ;
        } else {
            mon.setBackgroundColor(Color.rgb(220, 220, 220));
            date[2] = 0;


        }
    }

    public void onTuesday(View v) {
        if (date[3] == 0 && date[0] == 0) {
            tue.setBackgroundColor(Color.rgb(100, 100, 100));
            date[3] = 1;


        } else {
            tue.setBackgroundColor(Color.rgb(220, 220, 220));
            date[3] = 0;


        }
    }

    public void onWednesday(View v) {
        if (date[4] == 0 && date[0] == 0) {
            wed.setBackgroundColor(Color.rgb(100, 100, 100));
            date[4] = 1;


        } else {
            wed.setBackgroundColor(Color.rgb(220, 220, 220));
            date[4] = 0;


        }
    }

    public void onThursday(View v) {
        if (date[5] == 0 && date[0] == 0) {
            thu.setBackgroundColor(Color.rgb(100, 100, 100));
            date[5] = 1;

        } else {
            thu.setBackgroundColor(Color.rgb(220, 220, 220));
            date[5] = 0;


        }
    }

    public void onFriday(View v) {
        if (date[6] == 0 && date[0] == 0) {
            fri.setBackgroundColor(Color.rgb(100, 100, 100));
            date[6] = 1;


        } else {
            fri.setBackgroundColor(Color.rgb(220, 220, 220));
            date[6] = 0;


        }
    }

    public void onSaterday(View v) {
        if (date[7] == 0 && date[0] == 0) {
            sat.setBackgroundColor(Color.rgb(100, 100, 100));
            date[7] = 1;


        } else {
            sat.setBackgroundColor(Color.rgb(220, 220, 220));
            date[7] = 0;


        }
    }

    public void onSunday(View v) {
        if (date[1] == 0 && date[0] == 0) {
            sun.setBackgroundColor(Color.rgb(100, 100, 100));
            date[1] = 1;


        } else {
            sun.setBackgroundColor(Color.rgb(220, 220, 220));
            date[1] = 0;


        }
    }

    public void onAllday(View v) {
        if (date[0] == 0) {
            mon.setBackgroundColor(Color.rgb(220, 220, 220));
            tue.setBackgroundColor(Color.rgb(220, 220, 220));
            wed.setBackgroundColor(Color.rgb(220, 220, 220));
            thu.setBackgroundColor(Color.rgb(220, 220, 220));
            fri.setBackgroundColor(Color.rgb(220, 220, 220));
            sat.setBackgroundColor(Color.rgb(220, 220, 220));
            sun.setBackgroundColor(Color.rgb(220, 220, 220));
            all.setBackgroundColor(Color.rgb(100, 100, 100));
            date[0] = 1;
            date[1] = 0;
            date[2] = 0;
            date[3] = 0;
            date[4] = 0;
            date[5] = 0;
            date[6] = 0;
            date[7] = 0;


        } else {
            all.setBackgroundColor(Color.rgb(220, 220, 220));
            date[0] = 0;


        }
    }

    public void onOn(View v) {
        on.setBackgroundColor(Color.rgb(100, 100, 100));
        off.setBackgroundColor(Color.rgb(220, 220, 220));
        smart = "on";
    }

    public void onOff(View v) {
        off.setBackgroundColor(Color.rgb(100, 100, 100));
        on.setBackgroundColor(Color.rgb(220, 220, 220));
        smart = "off";
    }

    public void onOk(View v) {
        Intent intent = new Intent();

        String index;
        index = getintent.getStringExtra("index");

        intent.putExtra("hour", hour.getText().toString());
        intent.putExtra("minute", minute.getText().toString());
        intent.putExtra("position", index);
        intent.putExtra("day", date);
        intent.putExtra("smart", smart);
        setResult(RESULT_OK, intent);


        finish();
    }
}
