package kr.ac.kumoh.ce.s20110766.mytcp;


import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;
import android.widget.Toast;

import java.io.IOException;

public class AlarmSoundService extends Service {
    MediaPlayer mediaPlayer;
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mediaPlayer = new MediaPlayer();
        Intent i = new Intent(AlarmSoundService.this, ShowMsgActivity.class);
        //if(smart.equals("on")){Toast.makeText(AlarmSoundService.this,"smart "+smart,Toast.LENGTH_SHORT).show();}
        PendingIntent p = PendingIntent.getActivity(this, 0, i, 0);
        try {
            p.send();
        } catch (PendingIntent.CanceledException e) {
            e.printStackTrace();
        }

        try {
            mediaPlayer.setDataSource(this, alert);
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

        mediaPlayer.start();

        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // 서비스가 종료될 때 실행
       /* SharedPreferences sharedPreference
                = this.getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreference.edit();
        editor.putInt("size", AddAlarm.alarm_list.size());
*//***********************************************알람이 종료될때 최신 정보로 다시 수정**************************************************//*
        Integer write_count = 0;
        for (Integer i = 0; i < AddAlarm.alarm_list.size(); i++) {
            editor.putString("hour" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getCal().get(Calendar.HOUR_OF_DAY)));
            editor.putString("minute" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getCal().get(Calendar.MINUTE)));
            editor.putString("index" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getIndex()));
            editor.putString("set" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getset()));
            editor.putString("daysize" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getday().size()));
            for (Integer j = 0; j < AddAlarm.alarm_list.get(i).getday().size(); j++) {
                editor.putString("day" + write_count.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getday().get(j)));
                write_count++;
            }
        }
        editor.commit();*/
/*************************************************************************************************************************************/
        Toast.makeText(this, "알람이 종료됩니다", Toast.LENGTH_SHORT).show();
        mediaPlayer.stop(); // 음악 종료
    }
}
