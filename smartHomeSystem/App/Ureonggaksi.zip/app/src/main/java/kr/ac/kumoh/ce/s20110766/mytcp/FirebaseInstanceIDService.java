package kr.ac.kumoh.ce.s20110766.mytcp;

/**
 * Created by 태훈 on 2017-05-13.
 */

import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import java.util.HashMap;
import java.util.Map;


public class FirebaseInstanceIDService extends FirebaseInstanceIdService {

    private static final String TAG = "MyFirebaseIIDService";
    private String token;
    RequestQueue queue;
    // [START refresh_token]
    @Override
    public void onTokenRefresh() {
        // Get updated InstanceID token.
        token = FirebaseInstanceId.getInstance().getToken();
        Log.w(TAG, "Refreshed token: " + token);
        Log.d("uuu", token);

        // TODO: Implement this method to send any registration to your app's servers.

        queue = Volley.newRequestQueue(this);

        //AndroidId = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);

        requesttoken();
    }
    public void requesttoken() {
        String url = "http://192.168.43.149/register.php";

        // Request a string response from the provided URL.
        // 2) Request Obejct인 StringRequest 생성
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d("Response", response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                Log.d("uuu", token);
                params.put("Token", token);
                //params.put("android_id", AndroidId);
                return params;
            }
        };
        queue.add(postRequest);

    /*private static final String TAG = "MyFirebaseIIDService";

    @Override
    public void onTokenRefresh() {
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Refreshed token: " + refreshedToken);
        Log.d("uuu", refreshedToken);

        sendRegistrationToServer(refreshedToken);
    }

    private void sendRegistrationToServer(String token) {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = new FormBody.Builder()
                .add("Token", token)
                .build();
        Log.d("uuu", token);
        //request
        Request request = new Request.Builder()
                .url("http://192.168.0.11/fcm/register.php")
                .post(body)
                .build();

        Log.d("uuu", "iii");

        try {
            //FirebaseInstanceId.getInstance().deleteInstanceId();
            client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
    }
}

