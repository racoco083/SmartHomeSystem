package kr.ac.kumoh.ce.s20110766.mytcp;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by woong on 2017-04-06.
 */
public class AlarmReceiver extends BroadcastReceiver {
    static Intent mServiceintent;
    SharedPreferences pref;
    Integer read_count;
    int size;
    String hour;
    String minute;
    String smart;
    Boolean set;
    Integer index;
    Integer current_ds;
    Calendar mCalendar;
    Calendar next_time;
    Integer temp_day;
    Intent MI;
    PendingIntent rfp;
    RequestQueue queue;

    @Override
    public void onReceive(Context context, Intent intent) {
        queue = Volley.newRequestQueue(context);
        int requestCode = intent.getExtras().getInt("requestCode"); //몇번째 알람인지 체크해서 요일 change 해서 다시 등록하기 위해 받아오는 값
        AddAlarm.alarm_list.clear();
        Log.i("index",String.valueOf(requestCode));
        AddAlarm.alarm_list = new ArrayList<Alarm>();
/***********************************************앱 종료해있을 때 울리면 alarm_list정보 불러오기**************************************************/
        pref = context.getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
        size = pref.getInt("size", 0);
        read_count = 0;
        for (Integer i = 0; i < size; i++) {
            hour = pref.getString("hour" + i.toString(), "NOTFOUND");
            minute = pref.getString("minute" + i.toString(), "NOTFOUND");
            smart = pref.getString("smart" + i.toString(), "NOTFOUND");
            set = Boolean.valueOf(pref.getString("set" + i.toString(), "NOTFOUND"));
            index = Integer.parseInt(pref.getString("index" + i.toString(), "NOTFOUND"));
            current_ds = Integer.parseInt(pref.getString("daysize" + i.toString(), "NOTFOUND"));
            mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
            mCalendar.set(Calendar.MINUTE, Integer.parseInt(minute));
            mCalendar.set(Calendar.SECOND, 0);

            Alarm alarm = new Alarm();
            alarm.setIndex(index);
            alarm.setCal(mCalendar);
            alarm.set(set);
            alarm.setsmart(smart);


            for (Integer j = 0; j < current_ds; j++) {
                temp_day = Integer.parseInt(pref.getString("day" + read_count.toString(), "NOTFOUND"));
                alarm.setday(temp_day);
                read_count++;
            }
            AddAlarm.alarm_list.add(alarm);
        }
        Integer temp_day,right_day;
        temp_day=AddAlarm.alarm_list.get(requestCode).getday().get(0);
/***********************************************************************************************************************************************/
        AddAlarm.alarm_list.get(requestCode).change();      //요일 change
        right_day=AddAlarm.alarm_list.get(requestCode).getday().get(0);

        SharedPreferences sharedPreference
                = context.getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreference.edit();
        editor.putInt("size", AddAlarm.alarm_list.size());
/***********************************************알람이 종료될때 최신 정보로 다시 수정**************************************************/
        Integer write_count = 0;
        for (Integer i = 0; i < AddAlarm.alarm_list.size(); i++) {
            editor.putString("hour" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getCal().get(Calendar.HOUR_OF_DAY)));
            editor.putString("minute" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getCal().get(Calendar.MINUTE)));
            editor.putString("index" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getIndex()));
            editor.putString("set" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getset()));
            editor.putString("daysize" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getday().size()));
            editor.putString("smart" + i.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getsmart()));
            for (Integer j = 0; j < AddAlarm.alarm_list.get(i).getday().size(); j++) {
                editor.putString("day" + write_count.toString(), String.valueOf(AddAlarm.alarm_list.get(i).getday().get(j)));
                write_count++;
            }
        }
        editor.commit();

        mServiceintent = new Intent(context, AlarmSoundService.class);

        context.startService(mServiceintent);
        if(smart.equals("on")){
            Log.i("ddd","222");
            startSmart();}


/***********************************************다음 날짜로 알람 다시등록**************************************************/
        next_time = AddAlarm.alarm_list.get(requestCode).getCal();
        next_time.set(Calendar.DAY_OF_WEEK, AddAlarm.alarm_list.get(requestCode).getday().get(0));

        if(right_day<temp_day)
        {
            Calendar curCalendar = Calendar.getInstance();
                    next_time.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
        }
        MI = new Intent("com.test.alarmtestous.ALARM_START");
        MI.putExtra("requestCode", index);
        rfp =
                PendingIntent.getBroadcast(
                        context,
                        index,
                        MI,
                        PendingIntent.FLAG_UPDATE_CURRENT
                );

        MainActivity.mAlarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        if (AddAlarm.alarm_list.get(requestCode).getday().size() == 1) //요일 하나일 때
        {
            if (System.currentTimeMillis() >= next_time.getTimeInMillis()) //이미 지난시간이면 일주일 뒤로 등록
            {
                Calendar curCalendar = Calendar.getInstance();
                next_time.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
            }
        }

        MainActivity.mAlarmManager.set(
                AlarmManager.RTC_WAKEUP,
                next_time.getTimeInMillis(),
                rfp
        );
/**********************************************************************************************************************/
    }
    public void startSmart(){
        String url = "http://192.168.43.149/startSA.php";
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // response
                        Log.d("Response", response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Id", "111");
                Log.d("ccc", "111");
                return params;
            }
        };
        postRequest.setRetryPolicy(new DefaultRetryPolicy(0,-1,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Log.d("addd", "ddddd");
        queue.add(postRequest);
    }
}
