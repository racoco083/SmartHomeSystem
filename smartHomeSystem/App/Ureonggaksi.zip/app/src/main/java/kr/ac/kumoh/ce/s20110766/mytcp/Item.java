package kr.ac.kumoh.ce.s20110766.mytcp;

import java.io.Serializable;

/**
 * Created by 태훈 on 2017-04-07.
 */
public class Item implements Serializable {
    String hour;
    String minute;
    boolean state;


    public Item(String hour, String minute, boolean state_) {
        this.hour = hour;
        this.minute = minute;
        this.state = state_;
    }//여기서는 셋이 필요없다 생성할때 생성자에서 다 설정해주면 되기때문이다.

    public String getHour() {
        return hour;
    }

    public String getMinute() {
        return minute;
    }

    public boolean getState() {
        return state;
    }

    public void setState(boolean state_) {
        this.state = state_;
    }
}