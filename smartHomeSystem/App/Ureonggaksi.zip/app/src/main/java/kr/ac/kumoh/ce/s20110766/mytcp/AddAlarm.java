package kr.ac.kumoh.ce.s20110766.mytcp;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

import java.util.List;

public class AddAlarm extends AppCompatActivity {
    private static final int ACTIVITY_SETALARM = 1001;
    private static final int ACTIVITY_SETITEM = 1002;
    static List<Alarm> alarm_list = new ArrayList<Alarm>();
    Intent intent;

    ListView alarmList;
    Integer checked;

    public static Context mContext;


    ArrayList<Item> alarmArray = new ArrayList<Item>();
    Button remove;
    String hour;
    String minute;
    String smart;
    int index;
    int current_ds;
    Integer size;
    AlarmAdapter alarmAdapter;
    boolean set;
    Integer temp_day;
    Integer read_count;
    PendingIntent mPendingIntent;

    static Intent mAlarmIntent = new Intent("com.test.alarmtestous.ALARM_START");
    Calendar mCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addalarm);
        mCalendar = Calendar.getInstance();
        checked = 0;
        remove = (Button) findViewById(R.id.remove);
        intent = new Intent(this, SetAlarm.class);
        alarmAdapter = new AlarmAdapter(this, R.layout.item, alarmArray);
        alarmList = (ListView) findViewById(R.id.listView);
        alarmList.setAdapter(alarmAdapter);
        alarmList.setOnItemClickListener(new ListViewItemClickListener());
        mContext = this;
        alarm_list.clear();
        read_count = 0;

/***********************************************알람 정보 읽어오기**************************************************/
        SharedPreferences pref
                = getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
        size = pref.getInt("size", 0);
        for (Integer i = 0; i < size; i++) {
            hour = pref.getString("hour" + i.toString(), "NOTFOUND");
            minute = pref.getString("minute" + i.toString(), "NOTFOUND");
            smart = pref.getString("smart" + i.toString(), "NOTFOUND");
            set = Boolean.valueOf(pref.getString("set" + i.toString(), "NOTFOUND"));
            index = Integer.parseInt(pref.getString("index" + i.toString(), "NOTFOUND"));
            current_ds = Integer.parseInt(pref.getString("daysize" + i.toString(), "NOTFOUND"));
            mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
            mCalendar.set(Calendar.MINUTE, Integer.parseInt(minute));
            mCalendar.set(Calendar.SECOND, 0);

            Alarm alarm = new Alarm();
            alarm.setIndex(index);
            alarm.setCal(mCalendar);
            alarm.setsmart(smart);
            alarm.set(set);
            for (Integer j = 0; j < current_ds; j++) {
                temp_day = Integer.parseInt(pref.getString("day" + read_count.toString(), "NOTFOUND"));
                alarm.setday(temp_day);
                read_count++;
            }
            alarm_list.add(alarm);
            alarmArray.add(new Item(hour, minute, set));
        }

        alarmList.clearChoices();
        alarmAdapter.notifyDataSetChanged();
/******************************************************************************************************************/
    }

    @Override
    protected void onStop() {   //종료되거나 벗어날때 최신 정보로 갱신해두기
        super.onStop();
        SharedPreferences sharedPreference
                = this.getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreference.edit();
        editor.putInt("size", alarmArray.size());

        Integer write_count = 0;
        for (Integer i = 0; i < alarmArray.size(); i++) {
            editor.putString("hour" + i.toString(), alarmArray.get(i).getHour());
            editor.putString("minute" + i.toString(), alarmArray.get(i).getMinute());
            editor.putString("index" + i.toString(), String.valueOf(alarm_list.get(i).getIndex()));
            editor.putString("set" + i.toString(), String.valueOf(alarm_list.get(i).getset()));
            editor.putString("daysize" + i.toString(), String.valueOf(alarm_list.get(i).getday().size()));
            editor.putString("smart" + i.toString(), String.valueOf(alarm_list.get(i).getsmart()));

            for (Integer j = 0; j < alarm_list.get(i).getday().size(); j++) {
                editor.putString("day" + write_count.toString(), String.valueOf(alarm_list.get(i).getday().get(j)));
                write_count++;
            }
        }
        editor.commit();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            return;
        }
        //알람 수정시
        if (requestCode == ACTIVITY_SETITEM) {
            String hour = data.getStringExtra("hour");
            String minute = data.getStringExtra("minute");
            String smart = data.getStringExtra("smart");

            int position = Integer.valueOf(data.getStringExtra("position"));
            int count;
            int index;
            PendingIntent rmp, rfp;
            Calendar modify_calendar;
            Intent MI;
            count = alarmAdapter.getCount();

            if (count > 0) {
                if (position > -1 && position < count) {
                    index = alarm_list.get(position).getIndex();
                    MI = new Intent("com.test.alarmtestous.ALARM_START");
                    rmp =
                            PendingIntent.getBroadcast(
                                    AddAlarm.this,
                                    index,
                                    MI,
                                    PendingIntent.FLAG_UPDATE_CURRENT
                            );

                    MainActivity.mAlarmManager.cancel(rmp); //수정하기 전 알람 삭제

                    MI = new Intent("com.test.alarmtestous.ALARM_START");
                    modify_calendar = Calendar.getInstance();
                    modify_calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
                    modify_calendar.set(Calendar.MINUTE, Integer.parseInt(minute));
                    modify_calendar.set(Calendar.SECOND, 0);
                    MI.putExtra("requestCode", index);
                    rfp = PendingIntent.getBroadcast(
                            AddAlarm.this,
                            index,
                            MI,
                            PendingIntent.FLAG_UPDATE_CURRENT
                    );

/********************************************************* 요일 관련 코드 *******************************************************/
                    alarm_list.get(position).clear_list();

                    int day[];
                    day = data.getIntArrayExtra("day");
                    int day_count = 0;
                    for (Integer k = 0; k < 8; k++) {

                        if (day[k] == 1)
                            day_count++;
                    }

                    if (day_count == 0 || day[0] == 1)        //요일 설정 안했을때나 매일로 설정했을때==매일
                    {
                        for (Integer d = 1; d < 8; d++) {
                            alarm_list.get(position).setday(d);
                        }
                    } else {
                        for (Integer k = 1; k < 8; k++) {
                            if (day[k] == 1)
                                alarm_list.get(position).setday(k);
                        }
                    }
                    //오늘 날짜 알아오기
                    Calendar cal = Calendar.getInstance();
                    Integer nowday = cal.get(Calendar.DAY_OF_WEEK);

                    int c_hour = cal.get(Calendar.HOUR_OF_DAY);
                    int c_minute = cal.get(Calendar.MINUTE);
                    Integer comp;
                    int current_index = 0;

                    //오늘 날짜 기준으로 day 배열 정렬
                    for (Integer k = 0; k < alarm_list.get(position).getday().size(); k++) {
                        comp = alarm_list.get(position).getday().get(current_index);
                        if (nowday > comp) {
                            alarm_list.get(position).deleteday(current_index);
                            alarm_list.get(position).setday(comp);
                        } else if (nowday == comp) {
                            if (c_hour > Integer.valueOf(hour)) {
                                alarm_list.get(position).deleteday(current_index);
                                alarm_list.get(position).setday(comp);
                            } else if (c_hour == Integer.valueOf(hour) && c_minute > Integer.valueOf(minute)) {
                                alarm_list.get(position).deleteday(current_index);
                                alarm_list.get(position).setday(comp);
                            } else {
                                current_index++;
                            }
                        } else
                            current_index++;
                    }

                    alarm_list.get(position).setCal(modify_calendar);



/********************************************************* 요일 관련 코드 *******************************************************/
                if(alarm_list.get(position).getset()==true)
                {
                    modify_calendar.set(Calendar.DAY_OF_WEEK, alarm_list.get(position).getday().get(0));
                    if (alarm_list.get(position).getday().size() == 1) {
                        if (System.currentTimeMillis() >= modify_calendar.getTimeInMillis()) {
                            Calendar curCalendar = Calendar.getInstance();
                            modify_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                        }
                    }
                    Integer today,alarm_day;
                    alarm_day=AddAlarm.alarm_list.get(position).getday().get(0);
                    cal = Calendar.getInstance();
                    today = cal.get(Calendar.DAY_OF_WEEK);

                    if(today>alarm_day)
                    {
                        Calendar curCalendar = Calendar.getInstance();
                        modify_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                    }
                    MainActivity.mAlarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            modify_calendar.getTimeInMillis(),
                            rfp
                    ); //새 time으로 알람등록

                }

                alarm_list.get(position).setsmart(smart);
                alarmArray.set(position, new Item(hour, minute, alarm_list.get(position).getset()));
                // listview 선택 초기화.
                alarmList.clearChoices();
                // listview 갱신.

                alarmAdapter.notifyDataSetChanged();
                }
            }

            SharedPreferences sharedPreference
                    = this.getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
            // 2. get Editor
            SharedPreferences.Editor editor = sharedPreference.edit();
            // 3. set Key values
            editor.putInt("size", alarmArray.size());

            Integer write_count = 0;
            for (Integer i = 0; i < alarmArray.size(); i++) {
                editor.putString("hour" + i.toString(), alarmArray.get(i).getHour());
                editor.putString("minute" + i.toString(), alarmArray.get(i).getMinute());
                editor.putString("index" + i.toString(), String.valueOf(alarm_list.get(i).getIndex()));
                editor.putString("set" + i.toString(), String.valueOf(alarm_list.get(i).getset()));
                editor.putString("daysize" + i.toString(), String.valueOf(alarm_list.get(i).getday().size()));
                editor.putString("smart" + i.toString(), String.valueOf(alarm_list.get(i).getsmart()));
                for (Integer j = 0; j < alarm_list.get(i).getday().size(); j++) {
                    editor.putString("day" + write_count.toString(), String.valueOf(alarm_list.get(i).getday().get(j)));
                    write_count++;
                }

            }
            // 4. commit the values
            editor.commit();
        }
        //알람 등록시
        else if (requestCode == ACTIVITY_SETALARM) {
            String hour = data.getStringExtra("hour");
            String minute = data.getStringExtra("minute");
            String smart = data.getStringExtra("smart");

            alarmArray.add(new Item(hour, minute, true));

            mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour));
            mCalendar.set(Calendar.MINUTE, Integer.parseInt(minute));
            mCalendar.set(Calendar.SECOND, 0);

            Alarm alarm = new Alarm();

            alarm.setCal(mCalendar);
            int temp_index = alarm_list.size();

            alarm.setsmart(smart);
            alarm.set(true);
            alarm.setIndex(temp_index);


/********************************************************* 요일 관련 코드 *******************************************************/
            int day[];
            day = data.getIntArrayExtra("day");
            int count = 0;

            for (Integer k = 0; k < 8; k++) {

                if (day[k] == 1)
                    count++;
            }

            if (count == 0 || day[0] == 1)        //요일 설정 안했을때나 매일로 설정했을때==매일
            {
                for (Integer d = 1; d < 8; d++) {
                    alarm.setday(d);
                }
            } else {
                for (Integer k = 1; k < 8; k++) {
                    if (day[k] == 1)
                        alarm.setday(k);
                }
            }

            //오늘 날짜 알아오기
            Calendar cal = Calendar.getInstance();
            Integer nowday = cal.get(Calendar.DAY_OF_WEEK);

            int c_hour = cal.get(Calendar.HOUR_OF_DAY);
            int c_minute = cal.get(Calendar.MINUTE);
            Integer comp;
            int current_index = 0;

            //오늘 날짜 기준으로 day 배열 정렬
            for (Integer k = 0; k < alarm.getday().size(); k++) {
                comp = alarm.getday().get(current_index);
                if (nowday > comp) {
                    alarm.deleteday(current_index);
                    alarm.setday(comp);
                } else if (nowday == comp) {
                    if (c_hour > Integer.valueOf(hour)) {
                        alarm.deleteday(current_index);
                        alarm.setday(comp);
                    } else if (c_hour == Integer.valueOf(hour) && c_minute > Integer.valueOf(minute)) {
                        alarm.deleteday(current_index);
                        alarm.setday(comp);
                    } else {
                        current_index++;
                    }
                } else
                    current_index++;
            }

            for (int j = 0; j < alarm.getday().size(); j++) {
                Log.i("apply day", String.valueOf(alarm.getday().get(j)));
            }

            mCalendar.set(Calendar.DAY_OF_WEEK, alarm.getday().get(0));
/********************************************************* 요일 관련 코드 *******************************************************/

            alarm_list.add(alarm);

            mAlarmIntent.putExtra("requestCode", temp_index);
            mPendingIntent =
                    PendingIntent.getBroadcast(
                            this,
                            temp_index,
                            mAlarmIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT
                    );

            if (alarm_list.get(temp_index).getday().size() == 1) {
                if (System.currentTimeMillis() >= mCalendar.getTimeInMillis()) {
                    Calendar curCalendar = Calendar.getInstance();
                    mCalendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                }
            }
            Integer today,alarm_day;
            alarm_day=alarm_list.get(temp_index).getday().get(0);
            cal = Calendar.getInstance();
            today = cal.get(Calendar.DAY_OF_WEEK);

            if(today>alarm_day)
            {
                Calendar curCalendar = Calendar.getInstance();
                mCalendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
            }
            MainActivity.mAlarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    mCalendar.getTimeInMillis(),
                    mPendingIntent
            );

            alarmAdapter.notifyDataSetChanged();

            SharedPreferences sharedPreference
                    = this.getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
            // 2. get Editor
            SharedPreferences.Editor editor = sharedPreference.edit();
            // 3. set Key values
            editor.putInt("size", alarmArray.size());

            Integer write_count = 0;
            for (Integer i = 0; i < alarmArray.size(); i++) {
                editor.putString("hour" + i.toString(), alarmArray.get(i).getHour());
                editor.putString("minute" + i.toString(), alarmArray.get(i).getMinute());
                editor.putString("index" + i.toString(), String.valueOf(alarm_list.get(i).getIndex()));
                editor.putString("set" + i.toString(), String.valueOf(alarm_list.get(i).getset()));
                editor.putString("daysize" + i.toString(), String.valueOf(alarm_list.get(i).getday().size()));
                editor.putString("smart" + i.toString(), String.valueOf(alarm_list.get(i).getsmart()));

                for (Integer j = 0; j < alarm_list.get(i).getday().size(); j++) {
                    editor.putString("day" + write_count.toString(), String.valueOf(alarm_list.get(i).getday().get(j)));
                    write_count++;
                }

            }

            editor.commit();

        } else {

        }
    }

    public void onPlus(View v) {
        //  intent.putExtra("func","0");
        startActivityForResult(intent, ACTIVITY_SETALARM);
    }

    static class AlarmViewHolder {
        TextView hour;
        TextView minute;
        Button rb;
        Button onoffb;
        Button modb;
    }

    public class AlarmAdapter extends ArrayAdapter<Item> {
        int k;

        public AlarmAdapter(Context context, int resource, ArrayList<Item> objects) {
            super(context, resource, objects);
            k = resource;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            AlarmViewHolder holder;
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(k, parent, false);
                holder = new AlarmViewHolder();
                holder.hour = (TextView) convertView.findViewById(R.id.hour);
                holder.minute = (TextView) convertView.findViewById(R.id.minute);
                holder.rb = (Button) convertView.findViewById(R.id.remove
                );
                holder.onoffb = (Button) convertView.findViewById(R.id.onoff);
                holder.modb = (Button) convertView.findViewById(R.id.modify);
                convertView.setTag(holder);
            } else {
                holder = (AlarmViewHolder) convertView.getTag();
            }
            holder.hour.setText(getItem(position).getHour() + "시");
            holder.minute.setText(getItem(position).getMinute() + "분");
            String state;
            if (getItem(position).getState() == true) {
                holder.onoffb.setText("On");
            } else {
                holder.onoffb.setText("Off");
            }

            holder.rb.setTag(position);
            holder.rb.setOnClickListener(rmOnClickListener);

            holder.onoffb.setTag(position);
            holder.onoffb.setOnClickListener(OnOffClickListener);

            holder.modb.setTag(position);
            holder.modb.setOnClickListener(ModiClickListener);

            return convertView;
        }//리스트뷰를 스크롤로 내릴때마다 보여주는식으로 하여 매번 메모리를 새로 생성하지 않고 맨위에것을 다시 앞으로 보낸다.


    }

    Button.OnClickListener ModiClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {          //수정하기 버튼 클릭리스너
            int count;
            count = alarmAdapter.getCount();
            //Toast.makeText(this, "~~~~~~~~~~ ", Toast.LENGTH_SHORT).show();
            if (count > 0) {
                // 현재 선택된 아이템의 position 획득.
                int position = Integer.parseInt(v.getTag().toString());
                intent.putExtra("index", String.valueOf(position));
                checked = alarmList.getCheckedItemCount();
                startActivityForResult(intent, ACTIVITY_SETITEM);
            }
        }
    };
    Button.OnClickListener OnOffClickListener = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {       //ONOFF 버튼 클릭리스너


            int position = Integer.parseInt(v.getTag().toString());
            int count;
            int index;
            boolean state;
            PendingIntent rmp, rfp;
            Calendar change_calendar;
            Intent MI;
            count = alarmAdapter.getCount();
            state = alarm_list.get(position).getset();

            if (count > 0) {
                // 현재 선택된 아이템의 position 획득.

                if (position > -1 && position < count) {    //
                    // 아이템 삭제

                    if (state == true)                 //현재 ON 일때
                    {
                        index = alarm_list.get(position).getIndex();
                        MI = new Intent("com.test.alarmtestous.ALARM_START");
                        rmp =
                                PendingIntent.getBroadcast(
                                        AddAlarm.this,
                                        index,
                                        MI,
                                        PendingIntent.FLAG_UPDATE_CURRENT
                                );


                        MainActivity.mAlarmManager.cancel(rmp); //설정해둔 알람 삭제

                        alarm_list.get(position).set(false);
                        alarmArray.get(position).setState(false);

                    } else if (state == false)   //현재 OFF 일때
                    {
                        index = alarm_list.get(position).getIndex();
                        MI = new Intent("com.test.alarmtestous.ALARM_START");
                        MI.putExtra("requestCode", index);
                        rfp =
                                PendingIntent.getBroadcast(
                                        AddAlarm.this,
                                        index,
                                        MI,
                                        PendingIntent.FLAG_UPDATE_CURRENT
                                );


                        change_calendar = Calendar.getInstance();
                        change_calendar = alarm_list.get(position).getCal();


                        /********************************************************* 요일 관련 코드 *******************************************************/


                        //오늘 날짜 알아오기
                        Calendar cal = Calendar.getInstance();
                        Integer nowday = cal.get(Calendar.DAY_OF_WEEK);

                        int c_hour = cal.get(Calendar.HOUR_OF_DAY);
                        int c_minute = cal.get(Calendar.MINUTE);
                        int a_hour = change_calendar.get(Calendar.HOUR_OF_DAY);
                        int a_minute = change_calendar.get(Calendar.MINUTE);

                        Integer comp;
                        int current_index = 0;

                        //오늘 날짜 기준으로 day 배열 정렬
                        for (Integer k = 0; k < alarm_list.get(position).getday().size(); k++) {
                            comp = alarm_list.get(position).getday().get(current_index);
                            if (nowday > comp) {
                                alarm_list.get(position).deleteday(current_index);
                                alarm_list.get(position).setday(comp);
                            } else if (nowday == comp) {
                                if (c_hour > a_hour) {
                                    alarm_list.get(position).deleteday(current_index);
                                    alarm_list.get(position).setday(comp);
                                } else if (c_hour == a_hour && c_minute > a_minute) {
                                    alarm_list.get(position).deleteday(current_index);
                                    alarm_list.get(position).setday(comp);
                                } else {
                                    current_index++;
                                }
                            } else
                                current_index++;
                        }


                        change_calendar.set(Calendar.DAY_OF_WEEK, alarm_list.get(position).getday().get(0));
/********************************************************* 요일 관련 코드 *******************************************************/


                        if (alarm_list.get(position).getday().size() == 1) {
                            if (System.currentTimeMillis() >= change_calendar.getTimeInMillis()) {
                                Calendar curCalendar = Calendar.getInstance();
                                change_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                            }
                        }
                        Integer today,alarm_day;
                        alarm_day=AddAlarm.alarm_list.get(position).getday().get(0);
                        cal = Calendar.getInstance();
                        today = cal.get(Calendar.DAY_OF_WEEK);

                        if(today>alarm_day)
                        {
                            Calendar curCalendar = Calendar.getInstance();
                            change_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                        }

                        MainActivity.mAlarmManager.set(
                                AlarmManager.RTC_WAKEUP,
                                change_calendar.getTimeInMillis(),
                                rfp
                        );

                        alarm_list.get(position).set(true);
                        alarmArray.get(position).setState(true);

                    }

                    SharedPreferences sharedPreference
                            = getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
                    // 2. get Editor
                    SharedPreferences.Editor editor = sharedPreference.edit();
                    // 3. set Key values
                    editor.putInt("size", alarmArray.size());

                    Integer write_count = 0;
                    for (Integer i = 0; i < alarmArray.size(); i++) {
                        editor.putString("hour" + i.toString(), alarmArray.get(i).getHour());
                        editor.putString("minute" + i.toString(), alarmArray.get(i).getMinute());
                        editor.putString("index" + i.toString(), String.valueOf(alarm_list.get(i).getIndex()));
                        editor.putString("set" + i.toString(), String.valueOf(alarm_list.get(i).getset()));
                        editor.putString("daysize" + i.toString(), String.valueOf(alarm_list.get(i).getday().size()));
                        editor.putString("smart" + i.toString(), String.valueOf(alarm_list.get(i).getsmart()));

                        for (Integer j = 0; j < alarm_list.get(i).getday().size(); j++) {
                            editor.putString("day" + write_count.toString(), String.valueOf(alarm_list.get(i).getday().get(j)));
                            write_count++;
                        }

                    }
                    // 4. commit the values
                    editor.commit();
                    // listview 선택 초기화.
                    alarmList.clearChoices();

                    // listview 갱신.
                    alarmAdapter.notifyDataSetChanged();

                }
            }
        }


    };

    Button.OnClickListener rmOnClickListener = new Button.OnClickListener() {

        @Override
        public void onClick(View v) {   //삭제하기 버튼 클릭리스너
            int position = Integer.parseInt(v.getTag().toString());
            Toast.makeText(AddAlarm.this, String.valueOf(position), Toast.LENGTH_SHORT).show();
            int count;
            int index, ci;
            PendingIntent rmp, rfp;
            Calendar change_calendar;
            Intent MI;
            count = alarmAdapter.getCount();

            if (count > 0) {
                // 현재 선택된 아이템의 position 획득.

                if (position > -1 && position < count) {
                    // 아이템 삭제

                    index = alarm_list.get(position).getIndex();
                    MI = new Intent("com.test.alarmtestous.ALARM_START");
                    rmp =
                            PendingIntent.getBroadcast(
                                    AddAlarm.this,
                                    index,
                                    MI,
                                    PendingIntent.FLAG_UPDATE_CURRENT
                            );

                    MainActivity.mAlarmManager.cancel(rmp);

                    alarm_list.remove(position);
                    alarmArray.remove(position);

                    //삭제하면 인덱스가 달라지기 때문에 인덱스 관리 차원의 작업
                    for (int i = position; i < alarm_list.size(); i++) {
                        ci = alarm_list.get(i).getIndex();
                        MI = new Intent("com.test.alarmtestous.ALARM_START");
                        rmp =
                                PendingIntent.getBroadcast(
                                        AddAlarm.this,
                                        ci,
                                        MI,
                                        PendingIntent.FLAG_UPDATE_CURRENT
                                );
                        MainActivity.mAlarmManager.cancel(rmp); //알람취소

                        alarm_list.get(i).setIndex(i);  //index 다시바꾸기

                        if(alarm_list.get(i).getset()==true)
                        {
                        MI.putExtra("requestCode", i);
                        rfp = PendingIntent.getBroadcast(
                                AddAlarm.this,
                                i,
                                MI,
                                PendingIntent.FLAG_UPDATE_CURRENT
                        );


                        change_calendar = Calendar.getInstance();
                        change_calendar = alarm_list.get(i).getCal();
                        change_calendar.set(Calendar.DAY_OF_WEEK, alarm_list.get(i).getday().get(0));

                        if (alarm_list.get(i).getday().size() == 1) {
                            if (System.currentTimeMillis() >= change_calendar.getTimeInMillis()) {
                                Calendar curCalendar = Calendar.getInstance();
                                change_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                            }
                        }
                        Integer today, alarm_day;
                        alarm_day = AddAlarm.alarm_list.get(i).getday().get(0);
                        Calendar cal = Calendar.getInstance();
                        today = cal.get(Calendar.DAY_OF_WEEK);

                        if (today > alarm_day) {
                            Calendar curCalendar = Calendar.getInstance();
                            change_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                        }
                        MainActivity.mAlarmManager.set(
                                AlarmManager.RTC_WAKEUP,
                                change_calendar.getTimeInMillis(),
                                rfp
                        ); //새 index로 알람등록


                    }
                    }

                    SharedPreferences sharedPreference
                            = getSharedPreferences("MYPREFRENCE", Activity.MODE_PRIVATE);
                    // 2. get Editor
                    SharedPreferences.Editor editor = sharedPreference.edit();
                    // 3. set Key values
                    editor.putInt("size", alarmArray.size());

                    Integer write_count = 0;
                    for (Integer i = 0; i < alarmArray.size(); i++) {
                        editor.putString("hour" + i.toString(), alarmArray.get(i).getHour());
                        editor.putString("minute" + i.toString(), alarmArray.get(i).getMinute());
                        editor.putString("index" + i.toString(), String.valueOf(alarm_list.get(i).getIndex()));
                        editor.putString("set" + i.toString(), String.valueOf(alarm_list.get(i).getset()));
                        editor.putString("daysize" + i.toString(), String.valueOf(alarm_list.get(i).getday().size()));
                        editor.putString("smart" + i.toString(), String.valueOf(alarm_list.get(i).getsmart()));

                        for (Integer j = 0; j < alarm_list.get(i).getday().size(); j++) {
                            editor.putString("day" + write_count.toString(), String.valueOf(alarm_list.get(i).getday().get(j)));
                            write_count++;
                        }

                    }
                    // 4. commit the values
                    editor.commit();
                    // listview 선택 초기화.
                    alarmList.clearChoices();

                    // listview 갱신.
                    alarmAdapter.notifyDataSetChanged();

                }
            }
        }
    };

    private class ListViewItemClickListener implements AdapterView.OnItemClickListener
    {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String days="";


            for(Integer i=0;i<alarm_list.get(position).getday().size();i++)
            {
                switch (alarm_list.get(position).getday().get(i)) {
                    case 1 : days=days+" "+"일"; break;
                    case 2 : days=days+" "+"월"; break;
                    case 3 : days=days+" "+"화"; break;
                    case 4 : days=days+" "+"수"; break;
                    case 5 : days=days+" "+"목"; break;
                    case 6 : days=days+" "+"금"; break;
                    case 7 : days=days+" "+"토"; break;
                }

            }
            days=days+'\n'+"smart "+alarm_list.get(position).getsmart();
            Toast.makeText(AddAlarm.this,days,Toast.LENGTH_SHORT).show();
        }
    }

}
