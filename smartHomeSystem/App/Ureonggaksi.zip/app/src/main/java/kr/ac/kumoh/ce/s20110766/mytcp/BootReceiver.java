package kr.ac.kumoh.ce.s20110766.mytcp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by woong on 2017-05-13.
 */
public class BootReceiver extends BroadcastReceiver {
    SharedPreferences sharedPref;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(intent.ACTION_BOOT_COMPLETED)) {      //부팅시
/***********************************************부팅시 알람 관련 된 정보 가져오기**************************************************/
            AddAlarm.alarm_list = new ArrayList<Alarm>();
            AddAlarm.alarm_list.clear();
            sharedPref = context.getSharedPreferences("MYPREFRENCE", Context.MODE_PRIVATE);
            Integer read_count;
            int size1;
            int in;
            PendingIntent init_pi;
            Calendar init_calendar;
            Intent MI;
            String h, m;
            String s;
            boolean b;
            Integer current_ds;
            Integer temp_day;
            size1 = sharedPref.getInt("size", 0);
            read_count = 0;
            int current_index=0;
            Integer comp;
            for (Integer i = 0; i < size1; i++) {
                h = sharedPref.getString("hour" + i.toString(), "NOTFOUND");
                m = sharedPref.getString("minute" + i.toString(), "NOTFOUND");
                s = sharedPref.getString("smart" + i.toString(), "NOTFOUND");
                in = Integer.parseInt(sharedPref.getString("index" + i.toString(), "NOTFOUND"));
                b = Boolean.valueOf(sharedPref.getString("set" + i.toString(), "NOTFOUND"));
                current_ds = Integer.parseInt(sharedPref.getString("daysize" + i.toString(), "NOTFOUND"));
                Alarm alarm = new Alarm();
                alarm.setIndex(in);
                alarm.setsmart(s);
                init_calendar = Calendar.getInstance();
                init_calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(h));
                init_calendar.set(Calendar.MINUTE, Integer.parseInt(m));
                init_calendar.set(Calendar.SECOND, 0);
                alarm.setCal(init_calendar);
                alarm.set(b);

                for (Integer j = 0; j < current_ds; j++) {
                    temp_day = Integer.parseInt(sharedPref.getString("day" + read_count.toString(), "NOTFOUND"));
                    alarm.setday(temp_day);
                    read_count++;
                }


                AddAlarm.alarm_list.add(alarm);
/*********************************************************************************************************************************/
/***********************************************ON이 었던 알람 모두 다시 등록**************************************************/

                if (b == true) {
                    //오늘 날짜 알아오기
                    Calendar cal=Calendar.getInstance();
                    Integer nowday=cal.get(Calendar.DAY_OF_WEEK);
                    int c_hour=  cal.get(Calendar.HOUR_OF_DAY);
                    int c_minute=cal.get(Calendar.MINUTE);




                    //오늘 날짜 기준으로 day 배열 정렬(혹시 하루이상 전원 꺼둔 경우 대비
                    for(Integer k=0;k<AddAlarm.alarm_list.get(i).getday().size();k++)
                    {
                        comp=AddAlarm.alarm_list.get(i).getday().get(current_index);
                        if(nowday>comp)
                        {
                            AddAlarm.alarm_list.get(i).deleteday(current_index);
                            AddAlarm.alarm_list.get(i).setday(comp);
                        }
                        else if(nowday==comp)
                        {
                            if(c_hour>Integer.valueOf(h)){
                                AddAlarm.alarm_list.get(i).deleteday(current_index);
                                AddAlarm.alarm_list.get(i).setday(comp);
                            }
                            else if(c_hour==Integer.valueOf(h)&&c_minute>Integer.valueOf(m)){
                                AddAlarm.alarm_list.get(i).deleteday(current_index);
                                AddAlarm.alarm_list.get(i).setday(comp);
                            }
                            else{
                                current_index++;
                            }
                        }
                        else
                            current_index++;
                    }

                    init_calendar.set(Calendar.DAY_OF_WEEK, AddAlarm.alarm_list.get(i).getday().get(0));
                    if (AddAlarm.alarm_list.get(i).getday().size() == 1) {
                        if (System.currentTimeMillis() >= init_calendar.getTimeInMillis()) {
                            Calendar curCalendar = Calendar.getInstance();
                            init_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                        }
                    }
                    Integer today,alarm_day;
                    alarm_day=AddAlarm.alarm_list.get(i).getday().get(0);
                    cal = Calendar.getInstance();
                    today = cal.get(Calendar.DAY_OF_WEEK);

                    if(today>alarm_day)
                    {
                        Calendar curCalendar = Calendar.getInstance();
                        init_calendar.set(Calendar.WEEK_OF_YEAR, curCalendar.get(Calendar.WEEK_OF_YEAR) + 1);
                    }

                    MI = new Intent("com.test.alarmtestous.ALARM_START");
                    MI.putExtra("requestCode", in);
                    init_pi =
                            PendingIntent.getBroadcast(
                                    context,
                                    in,
                                    MI,
                                    PendingIntent.FLAG_UPDATE_CURRENT
                            );
                    MainActivity.mAlarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                    MainActivity.mAlarmManager.set(
                            AlarmManager.RTC_WAKEUP,
                            init_calendar.getTimeInMillis(),
                            init_pi
                    ); //새 index로 알람등록
                }
/***************************************************************************************************************************/
            }
        }
    }
}
